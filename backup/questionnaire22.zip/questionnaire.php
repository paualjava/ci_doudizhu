<?php
/*
* 减重报表
*
* ==============================================================================================================================================
* @auther 麦考林
*/
@ini_set("display_errors","On");
set_time_limit(0);
class questionnaire
{
	private $target_url 	     = "http://m.wm18.com";
	private $uid 	                 = 0;
	private $grant 	                 = 0;//是否授权 0是不授权 1是授权
	private $zhuanyuan_id 	         = 0;//专员id
	private $appid	                 = "wx8892dd7d58eec829";
	private $secret	                 = "0ab7f72a0390a00e660a6c443e2ea798";
	function __construct()
	{

		$this->zhuanyuan_id=trim($_GET['zhuanyuan_id']);
		$GLOBALS['smarty']->assign('zhuanyuan_id', $this->zhuanyuan_id);
		$this->uid=$_SESSION['user_id'];
		$GLOBALS['smarty']->assign('uid', $this->uid);
		$GLOBALS['smarty']->assign('path_dir',WAP_URL.'templates/activity/questionnaire/');
		$this->share();
	}
	/**
	 * 主页面
	 *
	 */
	function main()
	{
		$this->uid=2;
		if(empty($this->uid) && $this->grant==1)
		{
			$redirect_uri 	= urlencode('http://m.wm18.com/user.php?act=wx_one_key_login_action');
			$callback = urlencode("http://m.wm18.com/feature/questionnaire.php");		//回调地址 只用改这里的地址就行了。
			$url = 'https://open.weixin.qq.com/connect/oauth2/authorize?appid='.$this->appid.'&redirect_uri='.$redirect_uri.'&response_type=code&scope=snsapi_userinfo&state='.$callback.'&connect_redirect=1#wechat_redirect';
			ecs_header('location:'.$url);exit;
		}
		else
		{
			if(empty($this->zhuanyuan_id))
			{
				@header("Location: questionnaire.php?act=zhuanyuan\n", true);
				exit();
			}
			else
			{
				$GLOBALS['smarty']->display('activity/questionnaire/index.html');
			}
		}
	}
	function zhuanyuan()
	{
		//$this->uid=2;
		//$this->share();
		$GLOBALS['smarty']->display('activity/questionnaire/zhuanyuan.html');
	}
	/**
	 * ajax信息保存
	 *
	 */
	function ajax_save()
	{
		$data = array(
		'zhuanyuan'         =>trim($_POST['zhuanyuan_id']),//专员
		'name'              =>trim($_POST['name']),//姓名
		'phone'             =>trim($_POST['phone']),//电话
		'age'               =>trim($_POST['age']),//年龄
		'height'            =>trim($_POST['height']),//身高
		'weight'            =>trim($_POST['weight']),//体重
		'yaowei'            =>trim($_POST['yaowei']),//腰围
		'eat_more'          =>trim($_POST['eat_more']),//吃太多
		'weight_18'         =>trim($_POST['weight_18']),//18岁时平均体重
		'eat_pian'          =>trim($_POST['eat_pian']),//偏好食物
		'day_water'         =>trim($_POST['day_water']),//每日喝水的量
		'habit'             =>trim($_POST['habit']),//习惯
		'pinlv'             =>trim($_POST['pinlv']),//频率
		'pinlv_hecha'       =>trim($_POST['pinlv_hecha']),//喝咖啡或茶的频率
		'paibian'           =>trim($_POST['paibian']),//排便情况
		'shiyong'           =>trim($_POST['shiyong']),//是否在食用维您轻伊粉
		'time'              =>time()//时间
		);
		$GLOBALS['db']->autoExecute($GLOBALS['ecs']->table('questionnaire'),$data);
		$affect_row=$GLOBALS['db']->affected_rows();
		
		if($affect_row>0)
		{
			//BMI
			$weight=trim($_POST['weight']);
			$height_2=trim($_POST['height'])*trim($_POST['height']);
			$total_bmi=sprintf("%.2f",$weight/$height_2*10000);
			$total_bmi_lixiang=intval(22*$height_2/10000);
			$total_bmi_wanmei=intval($total_bmi_lixiang*0.9);
			$total_bmi_minus=$total_bmi_lixiang-$total_bmi_wanmei;
			$array=array("status"=>1,"total_bmi"=>$total_bmi,"total_bmi_lixiang"=>$total_bmi_lixiang,"total_bmi_wanmei"=>$total_bmi_wanmei,"total_bmi_minus"=>$total_bmi_minus);
		}
		else
		$array=array("status"=>0,"error"=>"数据提交失败");
		echo json_encode($array);die();
	}
	/**
		获取抽奖次数和积分和CLOP_userid
	*/
	function get_user_can()
	{
		$user_infoslq = "SELECT user_name,CLOP_userid,pay_points,real_name,mobile_phone FROM " .$GLOBALS['ecs']->table('users')." WHERE user_id = ".$this->uid;
		$user_info= $GLOBALS['db']->getRow($user_infoslq);
		//更新账户信息
		if($user_info['CLOP_userid']!=''){
			@UpdateCustAccount($user_info['user_name']);  //更新账户余额
		}
		//$user_info['pay_points']=38;
		$cannum0=floor($user_info['pay_points']/5);
		return array('cannum'=>$cannum0,'pay_points'=>trim($user_info['pay_points']),'CLOP_userid'=>trim($user_info['CLOP_userid']));
	}
	/**
	 * 抽奖程序
	 *
	 */
	function ajax_get_prize($uid)
	{
		//先查已经中奖的
		$uid=$_REQUEST['uid'];
		if($uid)
		{
			//查询用户信息
			$inf0=$this->get_user_can();
			//积分是否还足够抽奖
			$jf=$inf0['pay_points'];
			$clopid=$inf0['CLOP_userid'];
			$cannum=$inf0['cannum'];
			$pay_points=$inf0['pay_points'];
			if($jf>5)
			{
				$sql = "select * from ". $GLOBALS['ecs']->table('ggk')." where id=".$this->ggkid;
				$info = $GLOBALS['db']->getRow($sql);
				$temp_array=array(1=>"one",3=>"three",5=>"5");
				$array_count=array();
				foreach($temp_array as $key=>$value)
				{
					$column=$value."num";
					if($info[$column])
					{
						$total=$info[$value."has"];
						$val=(($info[$column]-$total)>0) ? $info[$column]-$total : 0;
						$array_count[$key]=$val;
					}
				}
				$chance=($info['chance']==0) ? 0 : $info['chance']/100;
				$result2=$this->get_prize_rand($array_count,$chance);

				$jiang=$temp_array[$result2];
				$jiang=$info[$jiang."txt"];
				//如果此人已经中过实物奖,那么给优惠券
				$sql = "select * from ".$GLOBALS['ecs']->table('ggklog')." where ggkid=".$this->ggkid." and user_id=".$uid. " and rid in(1,3,5) order by id desc limit 0,1";
				$info3 = $GLOBALS['db']->getRow($sql);
				if(!empty($info3))
				$result2=0;
				$jcode="";
				if($result2==0)
				{
					$jiang="木薯洁面仪优惠券120元";
					$jcode=$this->send_bonus($uid,$jiang,'choujiang_mushu_2');
					$array_this=array(1=>2,2=>4,3=>6);
					$rand=mt_rand(1,3);
					$result2=$array_this[$rand];
				}
				else
				{
					//更新数量
					$ridname=$temp_array[$result2];
					$ziduan=$ridname.'has';
					$sql2 = "UPDATE " .$GLOBALS['ecs']->table('ggk'). " SET  $ziduan=$ziduan+1   WHERE id =".$this->ggkid;
					$GLOBALS['db']->query($sql2);
					$this->jifen($uid,'choujiang_mushu_'.$result2);//只减去积分
				}
				//保存奖项
				$sql = "INSERT INTO " . $GLOBALS['ecs']->table('ggklog') . " (ggkid,jiang,jcode,rid,status,user_id,time,pay_points) " .
				"VALUES (".$this->ggkid.", '".$jiang."','".$jcode."','$result2','0','$uid','".gmtime()."','".$pay_points."')";
				$res = $GLOBALS['db']->query($sql);
				$array=array("zhi"=>$result2,"jiang"=>$jiang,"info"=>"ok","ci"=>$cannum,"jifen"=>$jf);
				echo json_encode($array);die();
			}
			else
			{
				$array=array("zhi"=>0,"info"=>"error","info2"=>"对不起,您的积分不足!");
				echo json_encode($array);die();
			}
		}
		else
		{
			$array=array("zhi"=>0,"info"=>"error");
			echo json_encode($array);die();
		}
	}
	/**
	 * 保存用户信息
	 *
	 */
	function ajax_save_info()
	{
		$uid=$_REQUEST['uid'];
		$name=$_REQUEST['name'];
		$phone=$_REQUEST['phone'];
		$address=$_REQUEST['address'];
		$provice = $_REQUEST['Select11'];
		$city = $_REQUEST['Select22'];
		$address=$provice." ".$city." ".$address;
		if(!empty($name) && !empty($uid))
		{
			$sql = "select * from ".$GLOBALS['ecs']->table('ggklog')." where ggkid=".$this->ggkid." and user_id=".$uid. " and rid in(1,3,5) order by id desc limit 0,1";
			$info = $GLOBALS['db']->getRow($sql);
			$id=$info['id'];
			$data = array();
			$data['name']		= $name;
			$data['shouji']		= $phone;
			$data['address']	= $address;
			$a=$GLOBALS['db']->autoExecute($GLOBALS['ecs']->table('ggklog'),$data,'',"id=".$id." limit 1");
			$array=array("result"=>1,"info"=>"ok");
			echo json_encode($array);die();
		}
		else
		{
			$array=array("result"=>0,"info"=>"error");
			echo json_encode($array);die();

		}
	}
	
	/**
	 * 分享
	 *
	 */
	function share()
	{
		// require_once "../jssdk.php";
		// $jssdk = new JSSDK($this->appid,$this->secret);
		// $signPackage = $jssdk->GetSignPackage();
		// $GLOBALS['smarty']->assign('signPackage' ,  $signPackage);
	}
}
define('IN_ECS', true);
require(dirname(dirname(__FILE__)) . '/includes/init.php');
//@ini_set('display_errors',"On");
$act=(empty($_REQUEST['act'])) ? "main" : $_REQUEST['act'];
$questionnaire = new questionnaire();
$sign=@is_callable(array($questionnaire,$act));
if($sign)
$questionnaire->$act();
else
ecs_header("Location:http://m.wm18.com/\n");
?>